
import telebot

TOKEN = "توکن_ربات_اینجا"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "سلام! به ربات کراش خوش اومدی :)")

bot.infinity_polling()
